# PCCOE_Diksha_123B1B249_CS1_AIML - AI-Powered AUTOSAR HLD Document Analysis Assistant (CS1)
Start with `Documentation/SUBMISSION_CHECKLIST.md`, then `Code/README.md`.
Folders: Synopsis - Input_Data - Code - Model_Prompts_Config - Evaluation_Results - Documentation - Video - Declarations.
