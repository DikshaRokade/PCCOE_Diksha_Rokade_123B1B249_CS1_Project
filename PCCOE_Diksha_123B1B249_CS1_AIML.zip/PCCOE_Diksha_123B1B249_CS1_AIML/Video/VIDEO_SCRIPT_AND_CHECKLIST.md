# Demo video (5-10 minutes) - script and checklist

Record the screen with your voice (OBS Studio, Zoom, or Win+G). Save as `Video/Demo_Diksha_123B1B249_CS1.mp4`. Target 8 minutes.
Before recording: `ollama serve` running, `ollama pull qwen2.5:7b-instruct` done, run `python Code/evaluation/evaluate.py --embedder bge --llm ollama`, start API and UI (see Code/README.md).

| Time | Show | Say |
|---|---|---|
| 0:00-0:40 | Title slide / README | Name, PRN, CS1, the problem: long HLD PDFs are hard to review manually. |
| 0:40-1:40 | `Input_Data/BDC_HLD_v1.0.pdf` (open a page with a table), `ground_truth/` folder | Knowledge base is synthetic (no real OEM data); 2 versions, seeded defects, ground-truth Q&A. |
| 1:40-3:00 | Architecture diagram (`Documentation/architecture_diagram.png`), `Model_Prompts_Config/config.yaml`, prompts | Pipeline: extraction -> chunking -> BGE embeddings -> ChromaDB + BM25 -> RRF -> gate -> local Qwen via Ollama -> citation check -> human review. Mention stack and why local. |
| 3:00-3:40 | UI > Documents tab: upload v1.0 and v1.1 | Ingestion output: pages, chunks, entities. |
| 3:40-5:30 | UI > Ask: "At what vehicle speed does auto-lock trigger?", "What ports does SWC_WindowCtrl have?", "Which components consume DoorLockState?", then out-of-scope "Who is the CEO of Bosch?" | Show citations (page/section), confidence, expand sources; show refusal for out-of-scope. Submit a review (accept) and show Review & audit tab. |
| 5:30-6:30 | UI > Entities, Consistency checks, Compare versions | R1-R4 findings with page numbers; v1.0 -> v1.1 changes (threshold 15 -> 20 km/h, new component). |
| 6:30-7:40 | `Evaluation_Results/metrics.json`, `metrics.png`, `qa_results.csv` | Hit@k/MRR ablation, answer accuracy, held-out set, groundedness, extraction/check F1. Be explicit about failures (H05, H06, H15 in the fallback run) and why. |
| 7:40-8:30 | Terminal: `python -m pytest Code/tests -q`; limitations slide | Synthetic data limits, no diagrams/OCR evaluation, lexical gate, substring metric. Your own contribution and what you would do next. |

Checklist: input data shown - pipeline shown - sample interactions - results and evaluation - grounded responses with citations - working behaviour. Mention any external dependency (one-time model downloads) at the start.
