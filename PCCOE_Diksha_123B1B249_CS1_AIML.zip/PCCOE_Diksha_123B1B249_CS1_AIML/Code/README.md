# AUTOSAR HLD Document Analysis Assistant (CS1)

Local RAG system that turns long AUTOSAR High-Level Design PDFs into a searchable, cited knowledge base.
Stack: PyMuPDF - ChromaDB + BM25 (RRF) - BGE-small embeddings - Ollama (Qwen2.5-7B) - FastAPI - Streamlit - SQLite - Docker.

## 1. Setup (Python 3.10+)
```bash
cd PCCOE_Diksha_123B1B249_CS1_AIML
python -m venv .venv && source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r Code/requirements.txt
export PYTHONPATH=$PWD/Code/src                           # Windows (PowerShell): $env:PYTHONPATH="$PWD\Code\src"
```
One-time downloads (internet needed ONLY for these; declare them in advance - see Declarations/):
* BGE embeddings are fetched automatically on first use (`BAAI/bge-small-en-v1.5`, ~130 MB).
* Local LLM: install Ollama from ollama.com, then `ollama pull qwen2.5:7b-instruct` (or `llama3.2:3b` for low-RAM laptops and set `llm.model` in `Model_Prompts_Config/config.yaml`).

Without these downloads the system still runs in an **offline fallback mode** (hash embeddings + extractive answers). Check which mode is active: `python -m hldrag.cli info`.

## 2. Run
```bash
python -m hldrag.cli ingest Input_Data/BDC_HLD_v1.0.pdf Input_Data/BDC_HLD_v1.1.pdf
python -m hldrag.cli ask "At what vehicle speed does auto-lock trigger?"
python -m hldrag.cli checks BDC-HLD-001@1.0
python -m hldrag.cli compare BDC-HLD-001@1.0 BDC-HLD-001@1.1

uvicorn hldrag.api:app --port 8000                         # terminal 1 (API docs: http://localhost:8000/docs)
streamlit run Code/app/streamlit_app.py                    # terminal 2 (UI: http://localhost:8501)
```
Default API keys (development only, change in config.yaml): `dev-engineer-key` (ingest/review) and `dev-viewer-key` (read-only). The UI uses the engineer key unless `HLD_API_KEY` is set.

## 3. Tests and evaluation
```bash
python -m pytest Code/tests -q                                        # 8 tests
python Code/evaluation/evaluate.py --embedder bge --llm ollama        # FINAL numbers (needs the downloads above)
python Code/evaluation/evaluate.py --embedder hash --llm extractive   # offline fallback run
python Code/scripts/build_report.py                                   # rebuild the PDF report from metrics.json
```
Outputs go to `Evaluation_Results/` (metrics.json, qa_results.csv, retrieval_ablation.csv, extraction_report.csv, checks_report.csv, sample_outputs.md, metrics.png, runs.jsonl).

## 4. Regenerate the synthetic data
`python Code/scripts/generate_synthetic_hld.py` rewrites the two PDFs and all ground-truth files in `Input_Data/`.

## 5. Docker (written, not executed in the build environment)
```bash
docker compose -f Code/docker-compose.yml up --build            # API :8000, UI :8501
docker compose -f Code/docker-compose.yml --profile llm up      # adds an Ollama container
```

## 6. Layout
`src/hldrag/`: ingest.py (PDF parsing, chunking) - extract.py (entities) - embeddings.py - store.py (ChromaDB) - retriever.py (hybrid, gate) - kb_tools.py (deterministic lookups) - llm.py (Ollama / extractive) - rag.py (pipeline, citation validation) - checks.py (R1-R7) - compare.py - db.py (SQLite) - pipeline.py (service) - api.py - cli.py.
