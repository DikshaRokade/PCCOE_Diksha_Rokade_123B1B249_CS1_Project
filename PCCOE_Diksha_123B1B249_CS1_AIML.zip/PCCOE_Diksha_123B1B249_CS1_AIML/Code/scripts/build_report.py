#!/usr/bin/env python3
"""Build Documentation/Technical_Report_Diksha_123B1B249_CS1.pdf from Evaluation_Results/metrics.json.
Re-run after every evaluation:  python Code/scripts/build_report.py"""
import csv
import json
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import Image, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

ROOT = Path(__file__).resolve().parents[2]
M = json.loads((ROOT / "Evaluation_Results" / "metrics.json").read_text())
R = M["run"]
fails = [r for r in csv.DictReader(open(ROOT / "Evaluation_Results" / "qa_results.csv", encoding="utf-8")) if r["correct"] != "True"]
fallback = R["embedder"].startswith("hash") or R["llm_mode"] == "extractive"

H1 = ParagraphStyle("H1", fontName="Helvetica-Bold", fontSize=14, spaceBefore=12, spaceAfter=5, keepWithNext=1, textColor=colors.HexColor("#1f3b63"))
H2 = ParagraphStyle("H2", fontName="Helvetica-Bold", fontSize=11, spaceBefore=8, spaceAfter=3, keepWithNext=1)
B = ParagraphStyle("B", fontName="Helvetica", fontSize=9.5, leading=13, spaceAfter=5)
BL = ParagraphStyle("BL", parent=B, leftIndent=12, bulletIndent=2)
C = ParagraphStyle("C", fontName="Helvetica-Oblique", fontSize=8.5, leading=11, spaceAfter=6)
T = ParagraphStyle("T", fontName="Helvetica-Bold", fontSize=20, leading=26, alignment=1, spaceAfter=8)
S = ParagraphStyle("S", fontName="Helvetica", fontSize=11, leading=15, alignment=1)
CELL = ParagraphStyle("CELL", fontName="Helvetica", fontSize=8, leading=10)
NOTE = ParagraphStyle("NOTE", parent=B, backColor=colors.HexColor("#fff4d6"), borderPadding=5, spaceBefore=4, spaceAfter=8)


def tbl(rows, widths, hdr=True):
    data = [[Paragraph(str(c), CELL) for c in r] for r in rows]
    t = Table(data, colWidths=widths, repeatRows=1 if hdr else 0)
    st = [("GRID", (0, 0), (-1, -1), 0.5, colors.HexColor("#777777")), ("VALIGN", (0, 0), (-1, -1), "TOP")]
    if hdr:
        st.append(("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#dde5f0")))
    t.setStyle(TableStyle(st))
    return t


def bullets(items):
    return [Paragraph(i, BL, bulletText="-") for i in items]


def footer(c, d):
    c.saveState(); c.setFont("Helvetica", 8)
    c.drawString(20 * mm, 12 * mm, "AIML Capstone - CS1 AUTOSAR HLD Document Analysis Assistant - Technical Report")
    c.drawRightString(190 * mm, 12 * mm, f"Page {d.page}"); c.restoreState()


qm, qh, ex, ck, rc, ab = M["qa_main"], M["qa_heldout"], M["extraction"]["micro"], M["consistency_checks"], M["revision_comparison"], M["retrieval_ablation"]
S_ = []
S_ += [Spacer(1, 60), Paragraph("TATA TECHNOLOGIES LTD. - TECH PULSE FY-26 | AI/ML Capstone Project", S), Spacer(1, 18),
       Paragraph("AI-Powered AUTOSAR HLD Document Analysis Assistant using Retrieval-Augmented Generation", T),
       Paragraph("Technical Report - Case Study CS1", S), Spacer(1, 30),
       tbl([["Student", "Diksha"], ["PRN", "123B1B249"], ["Programme / Batch", "B.Tech Computer Engineering, 2023-2027"],
            ["Institute", "Pimpri Chinchwad College of Engineering (PCCOE), Pune"], ["Case Study", "CS1 - AUTOSAR HLD Document Analysis Assistant"],
            ["Report date", R["timestamp"][:10]]], [120, 330], hdr=False), PageBreak()]

S_ += [Paragraph("1. Case Study and Project Title", H1),
       Paragraph("Case Study CS1 from the Automotive Engineering AI case-study document (v1.0, September 2026): an assistant that extracts, organises, "
                 "searches and validates architectural knowledge from long, unstructured AUTOSAR High-Level Design (HLD) PDFs. Engineers ask questions in "
                 "plain English and receive evidence-based answers with page and section citations; a human reviews every output.", B),
       Paragraph("2. Objectives", H1)]
S_ += bullets(["Reduce manual effort in reviewing HLD documents through cited question answering.",
               "Create a structured, searchable repository of components, ports, interfaces, signals, dependencies and requirements.",
               "Improve traceability and flag potential inconsistencies and missing dependencies.",
               "Support design review, onboarding and impact analysis, including comparison of document revisions."])
S_ += [Paragraph("3. Scope", H1), Paragraph("<b>Implemented:</b> controlled PDF ingestion; heading, table and metadata extraction; section-aware chunking; "
                                          "entity extraction; hybrid RAG with citations; relevance gate and abstention; deterministic KB tools; consistency checks R1-R7; "
                                          "revision comparison; CSV/JSON export; human review with audit trail; FastAPI + Streamlit; Docker; evaluation suite.", B),
       Paragraph("<b>Not implemented (by design):</b> automatic approval of architecture decisions; modification of source HLDs; parsing of diagrams; "
                 "enterprise IAM; graph database; use of real or copyrighted OEM / standards documents. OCR for scanned pages exists as an optional hook "
                 "(requires Tesseract) and was <b>not evaluated</b>.", B)]

S_ += [Paragraph("4. Proposed Approach and Implementation", H1), Paragraph("4.1 Models and stack", H2),
       tbl([["Component", "Choice", "Notes"],
            ["LLM", "Qwen2.5-7B-Instruct via Ollama (local); configurable", "Temperature 0; answers only from numbered sources; falls back to extractive generator if unavailable"],
            ["Embeddings", "BAAI/bge-small-en-v1.5 (sentence-transformers)", "Offline hashed-token embedder used only if BGE cannot load"],
            ["Vector store", "ChromaDB (persistent, cosine)", "Collection per project + embedder; metadata filters by document version"],
            ["Lexical index", "BM25 (rank-bm25), identifier-aware tokens", "Fused with dense results by Reciprocal Rank Fusion (k=60)"],
            ["Service / UI", "FastAPI, Streamlit, SQLite", "API-key roles (engineer / viewer); reviews and audit log in SQLite"],
            ["Packaging", "Docker, docker-compose, pytest", "Config hash and data hashes logged per evaluation run"]], [70, 150, 230]),
       Spacer(1, 6), Image(str(ROOT / "Documentation" / "architecture_diagram.png"), width=170 * mm, height=170 * mm * 0.58),
       Paragraph("Figure 1: System architecture", C),
       Paragraph("4.2 Pipeline", H2)]
S_ += bullets([
    "<b>Ingestion:</b> PyMuPDF reads text blocks, detects headings by font size, removes footers, and extracts tables (cell text is read by clipping, which keeps "
    "identifier underscores intact). Text becomes section-aware chunks (max 900 characters, one-sentence overlap); every table row becomes its own chunk.",
    "<b>Entity extraction:</b> typed tables are parsed into components, ports, interfaces, signals, connections, constraints and DIDs, each with page and section provenance, "
    "saved as a versioned knowledge base (JSON).",
    "<b>Retrieval:</b> dense (ChromaDB) and BM25 candidates are fused with RRF; top-6 chunks are returned. A <i>relevance gate</i> measures the share of query content "
    "terms found in the evidence and abstains below 0.6.",
    "<b>Deterministic KB tools:</b> questions about ports, dependencies, provider / consumer of a signal, CAN message fields and interfaces are answered from the extracted tables "
    "and passed to the generator as extra cited sources.",
    "<b>Generation and validation:</b> the LLM must cite every sentence as [S#]; unknown ids are stripped, groundedness and confidence are computed, and the response is marked "
    "for engineer review. Source text is treated as data, not instructions (prompt-injection control).",
    "<b>Checks and comparison:</b> rules R1-R7 (unconnected required port, signal length vs data type, undefined component, near-duplicate names, interface mismatch, undefined "
    "references, unused provided port) and entity / section diff between document versions."])

S_ += [Paragraph("5. Input Data / Knowledge Base", H1),
       Paragraph("Only <b>synthetic</b> data is used. <i>BDC_HLD_v1.0.pdf</i> and <i>BDC_HLD_v1.1.pdf</i> describe a fictitious Body Domain Controller (7-8 software components, "
                 "17-19 ports, 5-6 CAN signals, 8-10 connections, about 7 pages each) and were generated by Code/scripts/generate_synthetic_hld.py. Four defects are seeded in v1.0 "
                 "(unconnected required port, 8-bit signal vs uint16 data type, reference to an undefined component, DoorLockState vs DoorLockStatus) and two remain in v1.1. "
                 "Revision v1.1 adds a component, raises the auto-lock threshold from 15 to 20 km/h and widens one signal, which gives 10 expected changes for revision comparison. "
                 "Preprocessing and EDA: chunk counts (95 in v1.0, 105 in v1.1), table vs text chunk split, entity counts per category, and comparison with the ground-truth knowledge base.", B)]

S_ += [Paragraph("6. Evaluation", H1),
       Paragraph(f"<b>Configuration of the reported run:</b> embedder = {R['embedder']}, generation = {R['llm_mode']}"
                 + (f" ({R['llm_model']})" if R.get("llm_model") else "") + f", retrieval = {R['retrieval_mode']}, top-k = {R['top_k']}, "
                 f"config hash {R['config_hash']}, data hash {R['data_sha']}, run on {R['timestamp']}.", B)]
if fallback:
    S_ += [Paragraph("<b>Important:</b> this run used the offline fallback configuration (hashed lexical embeddings and/or extractive generation) because BGE and the local LLM "
                     "could not be loaded in the build environment. Dense semantic retrieval and LLM answer quality are therefore <b>not</b> represented by these numbers. "
                     "Re-run <i>python Code/evaluation/evaluate.py --embedder bge --llm ollama</i> and rebuild this report to obtain the final figures.", NOTE)]
S_ += [Paragraph("6.1 Method", H2),
       Paragraph("Questions: 31 answerable + 5 out-of-scope (main set) and 15 answerable + 3 out-of-scope (<b>held-out</b>, written after the pipeline was tuned on the main set). "
                 "Answer accuracy = all required key facts appear in the answer (strict substring proxy). Hit@k / MRR / evidence recall use gold evidence strings. "
                 "Groundedness = share of answer sentences carrying a valid [S#]; citation correctness = a cited source contains the gold evidence. "
                 "Extraction, consistency checks and revision comparison are scored against ground-truth files generated from the same data model as the PDFs.", B),
       Paragraph("6.2 Retrieval ablation (main set, answerable questions)", H2),
       tbl([["Mode", "Hit@1", "Hit@3", "Hit@6", "MRR", "Evidence recall@6"]] +
           [[m, ab[m]["hit@1"], ab[m]["hit@3"], ab[m]["hit@6"], ab[m]["mrr"], ab[m]["evidence_recall@6"]] for m in ("bm25", "dense", "hybrid")],
           [70, 60, 60, 60, 60, 110]),
       Paragraph("6.3 End-to-end question answering", H2),
       tbl([["Metric", "Main set", "Held-out set"],
            ["Questions", qm["n"], qh["n"]], ["Answer accuracy (answerable)", qm["answer_accuracy"], qh["answer_accuracy"]],
            ["Out-of-scope abstention rate", qm["oos_abstention_rate"], qh["oos_abstention_rate"]],
            ["False abstention rate", qm["false_abstention_rate"], qh["false_abstention_rate"]],
            ["Average groundedness", qm["avg_groundedness"], qh["avg_groundedness"]],
            ["Citation validity rate", qm["citation_validity_rate"], qh["citation_validity_rate"]],
            ["Citation correctness rate", qm["citation_correct_rate"], qh["citation_correct_rate"]],
            ["Latency mean / p95 (s)", f"{qm['latency_mean_s']} / {qm['latency_p95_s']}", f"{qh['latency_mean_s']} / {qh['latency_p95_s']}"]], [200, 120, 120]),
       Paragraph("6.4 Extraction, consistency checks and revision comparison", H2),
       tbl([["Task", "Precision", "Recall", "F1", "Detail"],
            ["Entity extraction (7 categories, 2 versions)", ex["precision"], ex["recall"], ex.get("f1", "-"), f"{ex['tp']}/{ex['gold']} records exact match"],
            ["Consistency checks v1.0", ck["1.0"]["precision"], ck["1.0"]["recall"], ck["1.0"]["f1"], f"{ck['1.0']['flagged_total']} flagged, {ck['1.0']['gold']} seeded"],
            ["Consistency checks v1.1", ck["1.1"]["precision"], ck["1.1"]["recall"], ck["1.1"]["f1"], f"{ck['1.1']['flagged_total']} flagged, {ck['1.1']['gold']} seeded"],
            ["Revision comparison v1.0 to v1.1", rc["precision"], rc["recall"], rc["f1"], f"{rc['tp']}/{rc['gold']} changes found"]], [150, 55, 50, 40, 155]),
       Spacer(1, 6), Image(str(ROOT / "Evaluation_Results" / "metrics.png"), width=165 * mm, height=165 * mm * 0.34),
       Paragraph("Figure 2: Retrieval ablation and headline metrics", C),
       Paragraph("6.5 Failure analysis", H2)]
if fails:
    S_ += [tbl([["ID", "Question", "Outcome", "Likely cause"]] +
               [[f["id"], f["question"], "abstained" if f["abstained"] == "True" else "incomplete answer", "paraphrase with little lexical overlap with the document (e.g. checksum vs CRC, lamp command vs LampCmd)"] for f in fails],
               [30, 190, 70, 160])]
else:
    S_ += [Paragraph("No failures in this run.", B)]
S_ += [Paragraph("The main-set scores are high partly because the pipeline was tuned on that set and the synthetic documents are clean and consistently formatted; the held-out set "
                 "is the more honest estimate and still reflects an easy dataset compared with real, hundreds-of-pages HLDs.", B)]

S_ += [Paragraph("7. Responsible AI, Security and MLOps", H1)]
S_ += bullets(["Grounding: every source carries version, page and section; unknown citation ids are removed; unsupported questions get an explicit abstention.",
               "Human oversight: each answer is accepted, edited or rejected in the UI and recorded with the user, time and sources; the audit log records ingestion, queries and reviews.",
               "Privacy and security: local models and vector store, no runtime external API, PDF type and size validation, API-key roles, source text treated as untrusted data.",
               "MLOps: pinned requirements, Dockerfile and docker-compose (written but not executed in the build environment), pytest suite (8 tests), run log with config and data hashes."])
S_ += [Paragraph("8. Limitations and Future Work", H1)]
S_ += bullets(["Synthetic, clean, single-column PDFs: real HLDs contain diagrams, merged table cells, scanned pages and inconsistent formatting. Diagram parsing is not supported; OCR is untested.",
               "Table typing relies on known column headers; other templates need new header mappings.",
               "The relevance gate is lexical, so heavily paraphrased questions can be wrongly refused (see failure analysis); BGE embeddings and a rewriting step should help.",
               "Accuracy uses substring matching; an LLM judge or manual grading would be fairer for free-text answers. The question sets are small (54 questions).",
               "Future work: revision graph and Neo4j traceability, role-based access per project, safety / cybersecurity integrations as in the case-study roadmap."])
S_ += [Paragraph("9. Student Contribution and AI-Tool Declaration", H1),
       Paragraph("Claude (Anthropic) was used as a coding and documentation assistant for scaffolding, debugging, the synthetic-data generator, test / evaluation scripts and drafting of documents. "
                 "The student reviewed, executed and is responsible for explaining all submitted artifacts. See Declarations/AI_Tool_Usage_Declaration.docx.", B),
       Paragraph("10. References", H1)]
S_ += bullets(["Automotive Engineering AI - Standard Project Case Study Document, v1.0, September 2026 (Case Study 1).",
               "BAAI/bge-small-en-v1.5 model card; Ollama and Qwen2.5 documentation; ChromaDB, FastAPI, Streamlit, PyMuPDF documentation.",
               "Reciprocal Rank Fusion: Cormack, Clarke and Buettcher, SIGIR 2009."])
SimpleDocTemplate(str(ROOT / "Documentation" / "Technical_Report_Diksha_123B1B249_CS1.pdf"), pagesize=A4, leftMargin=20 * mm, rightMargin=20 * mm,
                  topMargin=18 * mm, bottomMargin=20 * mm, title="Technical Report - CS1 AUTOSAR HLD Assistant", author="Diksha").build(S_, onFirstPage=footer, onLaterPages=footer)
print("report built")
