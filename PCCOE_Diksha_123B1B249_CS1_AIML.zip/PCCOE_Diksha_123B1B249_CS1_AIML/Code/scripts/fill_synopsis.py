#!/usr/bin/env python3
"""Fill the official synopsis template (keeps its formatting). Usage: python fill_synopsis.py <template.docx> <out.docx>"""
import copy
import sys
from pathlib import Path

from docx import Document
from docx.shared import Inches

ROOT = Path(__file__).resolve().parents[2]
tpl, out = sys.argv[1], sys.argv[2]
d = Document(tpl)
P = d.paragraphs
U = lambda p: p.text.strip().startswith("____")  # noqa: E731


def fill_field(i, value):
    p = P[i]
    done = False
    for r in p.runs:
        if "____" in r.text:
            if not done:
                r.text, r.bold, done = value, False, True
            else:
                r.text = ""
    assert done, i


def fill_slots(first, last, lines):
    """Replace the underscore paragraphs first..last (inclusive) by `lines`, cloning/removing slots as needed."""
    slots = [P[i] for i in range(first, last + 1)]
    assert all(U(s) for s in slots), (first, last)
    while len(slots) < len(lines):
        clone = copy.deepcopy(slots[-1]._p)
        slots[-1]._p.addnext(clone)
        from docx.text.paragraph import Paragraph
        slots.append(Paragraph(clone, slots[-1]._parent))
    for s, t in zip(slots, lines):
        runs = s.runs
        runs[0].text = t
        for r in runs[1:]:
            r._r.getparent().remove(r._r)
    for s in slots[len(lines):]:
        s._p.getparent().remove(s._p)


# header fields (indices are of the untouched template)
fill_field(5, "Pimpri Chinchwad College of Engineering (PCCOE), Pune")
fill_field(6, "B.Tech Computer Engineering, Batch 2023-2027")
fill_field(7, "Diksha")
fill_field(8, "123B1B249")
fill_field(10, "CS1")
fill_field(11, "AI-Powered AUTOSAR HLD Document Analysis Assistant using Retrieval-Augmented Generation (RAG)")

content = {  # (first, last): lines   -- processed bottom-up so earlier indices stay valid
    (15, 18): [
        "Reduce the manual effort of reviewing long AUTOSAR High-Level Design (HLD) documents by letting engineers ask questions in plain English and receive answers that cite the source page and section.",
        "Build a structured, searchable repository of architecture knowledge: components, ports, interfaces, signals, dependencies and non-functional requirements extracted from HLD PDFs.",
        "Improve component / interface / signal / dependency traceability and flag potential inconsistencies (unconnected required ports, signal-vs-datatype mismatches, undefined component references, terminology drift).",
        "Support design reviews, onboarding and impact analysis through revision comparison between HLD versions, while keeping an engineer in the loop to accept, edit or reject every AI output.",
    ],
    (22, 25): [
        "Controlled upload and ingestion of HLD PDFs: text, heading, table and metadata extraction with section-aware chunking (OCR hook for scanned pages).",
        "Architecture entity extraction (components, ports, interfaces, signals, connections, constraints, diagnostic data identifiers) stored as a versioned knowledge base with page provenance.",
        "Hybrid RAG question answering (ChromaDB dense search + BM25, fused by RRF) using a local LLM, with page/section citations, confidence indicator, relevance gate that abstains when evidence is missing, and citation validation.",
        "Deterministic tools and rules: dependency / port / signal lookups, consistency checks R1-R7, revision comparison, CSV/JSON export, human review (accept / edit / reject) with SQLite audit trail, FastAPI + Streamlit interface, Docker packaging, evaluation scripts.",
    ],
    (27, 29): [
        "No automatic approval of architecture decisions and no modification of source HLD documents; every output is a draft for engineer review.",
        "No use of confidential OEM / AUTOSAR-consortium documents or copyrighted standards text: only a synthetic HLD dataset created for this project is used. Parsing of diagrams / figures is out of scope (text and tables only); OCR is provided as an optional, unevaluated hook.",
        "No external API calls at runtime; no replacement of formal architecture governance, and no enterprise IAM / graph database (listed as future scope).",
    ],
    (32, 33): [
        "Qwen2.5-7B-Instruct (Ollama tag qwen2.5:7b-instruct), served locally through Ollama on the student machine; no source text leaves the machine. The model name is a configuration value (e.g. llama3.2:3b for low-RAM laptops).",
        "Answers are generated at temperature 0 from numbered sources only; if the local LLM is unavailable the system falls back to a deterministic extractive generator so that the pipeline still runs offline.",
    ],
    (35, 36): [
        "BAAI/bge-small-en-v1.5 via sentence-transformers (384-dimensional, normalised), run locally after a one-time model download.",
        "Offline fallback: deterministic hashed bag-of-identifier-tokens embedder, used only when BGE cannot be loaded; the embedder used is recorded in every evaluation run.",
    ],
    (38, 39): [
        "ChromaDB (persistent, local) with cosine distance; one collection per project and embedder, metadata (document version, page, section, chunk type) enables per-version filtering.",
        "A BM25 index over identifier-aware tokens (SWC_DoorLockMgr -> swc, door, lock, mgr) complements dense search to handle exact names and numbers.",
    ],
    (41, 42): [
        "Pipeline: PDF -> extraction (text, headings, tables) -> section-aware chunks (text chunks and one chunk per table row) -> embeddings -> ChromaDB. Query -> deterministic KB tools + hybrid retrieval (top-6) -> relevance gate (share of query terms found in the evidence) -> grounded generation -> citation validation -> confidence -> engineer review.",
        "Prompt rules: answer only from numbered sources, cite every sentence as [S#], reply INSUFFICIENT_EVIDENCE when unsupported, and treat source text as data (prompt-injection control). No autonomous agent: a fixed, auditable pipeline was chosen because the use case needs traceability.",
    ],
    (44, 45): [
        "FastAPI backend: document upload (PDF validation, size limit), query, entities, checks, comparison, review, audit and CSV export endpoints; API-key authentication with engineer / viewer roles.",
        "Streamlit front end with tabs for documents, Q&A with expandable source citations, entity tables, consistency checks, version comparison and review / audit log. SQLite stores documents, reviews and audit events.",
    ],
    (47, 48): [
        "Deterministic KB tools answer structured questions (ports of a component, dependencies, provider / consumer of a signal, CAN message fields, interface kind and data type) directly from the extracted tables, with page provenance.",
        "Rule-based checks: R1 required port without provider, R2 signal length vs interface data type, R3 undefined component reference, R4 near-duplicate names, R5 interface mismatch across a connection, R6 undefined references, R7 provided port without consumer. Revision comparison diffs two knowledge bases and section texts.",
    ],
    (54, 55): [
        "Synthetic Body Domain Controller (BDC) HLD documents, version 1.0 and 1.1, generated by Code/scripts/generate_synthetic_hld.py. All text is original; no real OEM or standards content is used.",
        "Seeded defects (4 in v1.0, 2 in v1.1), a 31-question ground-truth Q&A set, 5 out-of-scope questions, an 18-question held-out set written after tuning, and ground-truth entity files, all stored under Input_Data/ground_truth.",
    ],
    (57, 58): [
        "Two PDFs of about 7 pages each, generated with ReportLab: roughly 100 chunks per document, 7-8 software components, 17-19 ports, 5-6 signals and 8-10 connections.",
        "Ground-truth files are JSON; evaluation outputs are CSV / JSON / PNG / Markdown.",
    ],
    (60, 61): [
        "Preprocessing: header / footer removal, heading-level detection from font size, table detection and header-based table typing, whitespace normalisation, sentence-aware chunking (max 900 characters, 1-sentence overlap), identifier-aware tokenisation.",
        "EDA: chunk counts and lengths per document, entity counts per category, distribution of table vs text chunks, and a comparison of extracted entities with the ground-truth knowledge base.",
    ],
    (64, 65): [
        "Component / interface / signal / dependency inventory, searchable Q&A responses with page citations, functional-flow summaries, a potential inconsistency report, revision-change report and structured CSV / JSON export (as listed for Case Study 1).",
        "Every response carries sources, a confidence indicator and a review status; accepted, edited or rejected decisions are logged.",
    ],
    (67, 68): [
        "Test set: 31 answerable and 5 out-of-scope questions plus an 18-question held-out set (15 answerable, 3 out-of-scope) with must-contain facts and gold evidence strings. Metrics: Hit@k, MRR and evidence recall (BM25 vs dense vs hybrid ablation), answer accuracy, abstention rate on out-of-scope questions, false-abstention rate, groundedness, citation validity and correctness, latency.",
        "Extraction precision / recall / F1 against the ground-truth knowledge base, precision / recall of consistency checks against seeded defects, and F1 of revision comparison. The held-out set is reported separately so tuning on the main set is not hidden.",
    ],
    (70, 71): [
        "Grounding and citations (page and section for every source), abstention when evidence is insufficient, citation validation that removes unknown source ids, confidence indicator, mandatory human review with an audit trail, and a statement that outputs are decision support only.",
        "Privacy and security: fully local models and vector store, no external API at runtime, PDF type / size validation, API-key roles, source text treated as untrusted data (prompt-injection rule), synthetic data only.",
    ],
    (73, 74): [
        "Versioning: Git for code; SHA-256 hashes of input files and a configuration hash are recorded with each evaluation run; document versions are kept side by side in the vector store.",
        "Docker and docker-compose (API, UI, optional Ollama service), pytest test suite, and lightweight experiment tracking in Evaluation_Results/runs.jsonl (embedder, LLM mode, config hash, headline metrics).",
    ],
    (78, 78): ["Claude (Anthropic) - chat assistant used for coding and documentation assistance."],
    (80, 80): ["Code scaffolding and debugging, generation of the synthetic dataset script, evaluation and test scripts, and drafting of the synopsis, report and video script. All generated code is reviewed, executed and understood by the student, who remains responsible for explaining it."],
    (82, 82): ["Code/ (src, scripts, tests, evaluation, app), Input_Data/ (synthetic HLD generator), Model_Prompts_Config/ (prompts), Documentation/ (report, README), Video/ (script), Synopsis/."],
}
for (a, b), lines in sorted(content.items(), reverse=True):
    fill_slots(a, b, lines)

# architecture diagram in place of the placeholder (index 50 is unaffected by bottom-up edits)
ph = P[50]
for r in ph.runs[1:]:
    r._r.getparent().remove(r._r)
ph.runs[0].text = ""
ph.runs[0].add_picture(str(ROOT / "Documentation" / "architecture_diagram.png"), width=Inches(6.4))
d.save(out)
print("saved", out)
